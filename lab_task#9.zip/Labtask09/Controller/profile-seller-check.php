<?php 
	
	$name =								 "";
	$email=							"";
	$gender=					"";
	$phone=					"";
	$city=				"";
	$paddress=		"";
	$peraddress="";


					$uname=$_SESSION['row']['uname'];
                	$_SESSION['name'] = $_SESSION['row']['name'];
					$name =								 $_SESSION['row']['name'];
					$email=							$_SESSION['row']['email'];
					$gender=					$_SESSION['row']['gender'];
					$phone=					$_SESSION['row']['phone'];
					$city=				$_SESSION['row']['city'];
					$paddress=		$_SESSION['row']['paddress'];
					$peraddress=$_SESSION['row']['peraddress'];
        
?>