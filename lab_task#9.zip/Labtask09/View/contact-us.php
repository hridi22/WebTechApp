<!DOCTYPE html>
<html>
<head>
	<title>Contact us</title>
  <?php include_once 'header.php' ?>
</head>

<body>
 <div>
 	   <h3 style="color: red; background-color: yellow;" align="center">Contact us</h3>
 </div>

 <table>
  
  <tr>
    <td>Title</td>
    <td>Details</td>
   
  </tr>
  <tr>
    <td>Name</td>
    <td>Francisco Chang</td>

  </tr>
  <tr>
    <td>Number</td>
    <td>+8801734934035</td>

  </tr>
  <tr>
    <td>E-mail</td>
    <td>info@eshop.com</td>

  </tr>
  <tr>
    <td>Address</td>
    <td>1/10 Road, Banani, Dhaka</td>

  </tr>
</table>

  <?php include_once 'footer.php' ?>

</body>
</html>