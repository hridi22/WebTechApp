<?php 
    unset($_SESSION['flag']);
    header('location: ../view/login.php');
?>