<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <title>E-Shop.com</title>

   <?php include_once 'header.php' ?>

</head>

<body>
   <h3 class="title">Home</h3>
   <!--nav sec strt here--> 
   <div class="nav">
      <div class="wraper">
         <div class="nav-bar">
            <ul>
               <li><a href="#">Home</a></li>
               <li><a href="./products.php">Products</a></li>
               <li><a href="./addProduct.php">Add Products</a></li>
                <li><a href="./searchProduct.php">Search Products</a></li>
               <li><a href="./contact-us.php">Contact us</a></li>
             <!--  <li><a href="#">Phone</a></li>
               <li><a href="#">Order</a></li>
            --></ul>
         </div>
      </div>
   </div>
   <!--nav sec end here--> 


   <?php include_once 'footer.php' ?>
   


</body>
</html>