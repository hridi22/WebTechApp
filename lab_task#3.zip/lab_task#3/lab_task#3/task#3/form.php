<!DOCTYPE html>
<html>
   <body>
      <fieldset>
         <legend><b>Profile Picture </b></legend>
         <form action="upload.php" method="post" enctype="multipart/form-data">
            Select image to upload:<br>
            <input type="file" name="fileToUpload" id="fileToUpload"><br>
            <hr>
            <input type="submit" value="Upload Image" name="submit">
         </form>
      </fieldset>
   </body>
</html>