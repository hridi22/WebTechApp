
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History</title>

    <?php include_once ('./header.php'); ?>
    <?php include_once ('../Controller/history-check.php'); ?>

</head>
<body>
<div>
 	   <h3 style="color: red; background-color: yellow;" align="center">My Profile</h3>
 </div>
</body>
</html>

<?php 
    include_once ('./footer.php');
?>